from flask import Flask, request, jsonify
from flask_cors import CORS
from utils.harrassment_model import detect_harassment

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS so frontend can communicate with backend

# Home route (just to test if backend is running)
@app.route("/")
def home():
    return jsonify({"message": "SAARTHI.AI Backend is running!"})

# API route for harassment detection
@app.route("/api/detect", methods=["POST"])
def detect():
    data = request.get_json()
    if not data or "text" not in data:
        return jsonify({"error": "Missing 'text' in request"}), 400

    text = data["text"]
    result = detect_harassment(text)
    return jsonify({"result": result})

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
