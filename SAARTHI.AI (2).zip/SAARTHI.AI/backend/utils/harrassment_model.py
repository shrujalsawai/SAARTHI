# harrassment_model.py
import torch
import torch.nn as nn

MODEL_PATH = "utils/harrassment_model.pt"

class DummyHarassmentModel(nn.Module):
    def __init__(self):
        super(DummyHarassmentModel, self).__init__()
        self.fc = nn.Linear(10, 2)  # dummy layers

    def forward(self, x):
        return self.fc(x)

# harrassment_model.py (dummy version for testing)
class HarassmentModel:
    def __init__(self):
        pass  # No real model needed for testing

    def predict(self, text):
        # Simulate harassment detection: return True if 'harass' is in text
        return "harass" in text.lower()

def detect_harassment(text):
    model = HarassmentModel()
    return model.predict(text)

