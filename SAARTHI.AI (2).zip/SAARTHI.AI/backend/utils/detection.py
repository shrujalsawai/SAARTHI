import tkinter as tk
from tkinter import messagebox
from .harrassment_model import detect_harassment

def check_harassment(text):
    result = detect_harassment(text)
    if result:
        root = tk.Tk()
        root.withdraw()  # Hide main window
        messagebox.showwarning("Harassment Detected", "Warning! Harassment detected in the text.")
        root.destroy()
    else:
        print("No harassment detected.")

# Example test
if __name__ == "__main__":
    sample_text = "This is a harassment example."
    check_harassment(sample_text)

