import torch
import torch.nn as nn

# Dummy model class
class DummyModel(nn.Module):
    def __init__(self):
        super(DummyModel, self).__init__()
        self.linear = nn.Linear(1, 1)

    def forward(self, x):
        return self.linear(x)

# Instantiate and save the dummy model
model = DummyModel()
torch.save(model, "harrassment_model.pt")  # Saves in the same folder
print("Dummy model saved as harrassment_model.pt")
