const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 5000;

app.use(cors());

// Sample alerts
let alerts = [
  {
    time: "14:23:45",
    location: "Central Park - Cam #12",
    type: "Physical Aggression",
    confidence: 89,
  },
  {
    time: "13:45:12",
    location: "Market St - Cam #05",
    type: "Verbal Harassment",
    confidence: 76,
  },
  {
    time: "11:30:22",
    location: "Bus Station - Cam #08",
    type: "Suspicious Following",
    confidence: 82,
  },
];

app.get("/alerts", (req, res) => {
  // Return a random alert to simulate live updates
  const randomAlert = alerts[Math.floor(Math.random() * alerts.length)];
  res.json(randomAlert);
});

app.listen(PORT, () => {
  console.log(`Backend running at http://localhost:${PORT}`);
});
