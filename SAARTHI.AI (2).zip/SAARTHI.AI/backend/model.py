import torch
from utils.harrassment_model import HarrassmentModel  # Assuming your model class is here

# Load the model
model = HarrassmentModel()
model.load_state_dict(torch.load("utils/harrassment_model.pt", map_location=torch.device('cpu')))
model.eval()

def detect_harassment(text):
    """
    Returns True if harassment detected, False otherwise
    """
    # Convert text to model input here (e.g., tokenize)
    # For demonstration, let's assume text "bad" triggers harassment
    # Replace with actual preprocessing and model inference
    if "bad" in text.lower():
        return True
    return False
